# Aplicación a interfaces digitales

Usar la [paleta web indicada por Diseño](web-palette.md), aportada el 23 de septiembre de 2026. Esa fuente prevalece sobre los colores del anteproyecto para web y aplicaciones. La asignación a componentes que sigue es una propuesta de implementación, no un sistema de componentes aprobado por el estudio.

## Integración en un proyecto

Copiar únicamente los recursos utilizados desde `assets/` al lugar de recursos del proyecto. No crear dependencias en tiempo de ejecución hacia la carpeta personal de skills. No incluir el PDF de referencia en el paquete público por defecto.

Usar `assets/brand-tokens.json` como fuente legible por código y `assets/brand-tokens.css` como punto de partida para CSS. Las variables llevan el prefijo `--cs-` y no cambian estilos globales de componentes. Si el proyecto tiene tokens propios, mapear los valores a su esquema en vez de mantener dos temas competidores.

Los tokens incluyen las escalas verde, lima y bronce de 50 a 900, y el naranja `#F6511D`. Los colores principales son verde `#19542C`, lima `#B7E768`, bronce `#E5B25D` y naranja `#F6511D`. Los alias semánticos y las familias de respaldo son propuestas de esta skill. No convertir radios, espacios o sombras existentes en nuevas reglas de marca por inferencia.

Para migrar una implementación anterior, reemplazar los seis colores derivados del anteproyecto por los nuevos tokens según su función. `--cs-forest` y `--cs-lime` quedan como alias compatibles hacia verde 500 y lima 500; `--cs-orange` ahora vale `#F6511D`. `--cs-cream`, `--cs-terracotta` y `--cs-earth-red` no forman parte del tema web: revisar sus usos y elegir superficie o acento apropiado. La skill no modifica automáticamente proyectos que ya hayan copiado los recursos.

## Composición propuesta

- Fondos verde 50 (`#F0F4F1`) con texto verde 900; cabeceras y secciones de marca en verde 500 con contenido verde 50.
- Botones principales verde 500/verde 50 como opción inicial; lima 500 y bronce 500 para acentos, con texto oscuro. El naranja es un acento adicional, no una asignación automática de error o aviso.
- Logo horizontal donde el espacio favorezca una línea; logo en dos líneas para composiciones compactas; símbolo para avatares o espacios reducidos con identificación accesible de la marca.
- Usar los SVG de `assets/logos/web/`; elegir `-green.svg` para fondos claros y `-light.svg` para fondos oscuros. En un SVG externo, las variables CSS del documento no reemplazan el atributo de color del archivo.
- Motivos recortados del símbolo como decoración secundaria, sin interferir con texto ni controles.
- Inter para lectura y controles digitales. Seitu puede aportar carácter institucional en títulos si está disponible y su carga funciona.

No convertir todos los colores en estados funcionales: éxito, aviso y error necesitan etiquetas, iconos u otras señales y deben conservar la semántica del producto. La paleta de marca no define esos estados.

## Fuentes

Las pilas CSS nombran las familias y sus alternativas, pero no las descargan ni generan `@font-face`. Incorporar fuentes locales o ya disponibles en el proyecto y comprobar el resultado real. No introducir un servicio remoto de fuentes solo porque aparezca un nombre en el PDF.

Una pila con Seitu seguida de Inter expresa preferencia y respaldo; no prueba que Seitu esté cargada. Si falta, comunicar la sustitución. No simular el logotipo con ninguna de esas pilas.

## Verificación relevante

Comprobar los SVG a su tamaño de uso, los fondos que los rodean y la lectura móvil. Medir el contraste de las combinaciones finales cuando la interfaz lo requiera, especialmente texto sobre lima o naranja. Verificar navegación por teclado y estados visibles si se han creado controles. Mantener textos alternativos útiles para logos y ocultar a tecnologías de asistencia los motivos puramente decorativos.

No reemplazar datos funcionales por los ejemplos del PDF. Consultar la fuente del proyecto para tarifas, recorridos, contactos, horarios y categorías.
