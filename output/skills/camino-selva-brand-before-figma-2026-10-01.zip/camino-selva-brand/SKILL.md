---
name: camino-selva-brand
description: Aplicar o revisar la identidad visual de Camino Selva en sitios web, aplicaciones, presentaciones, documentos y piezas de comunicación. Incluye la paleta web indicada por Diseño, guía de marca y logos SVG. Usar cuando el proyecto sea de Camino Selva o el usuario solicite esta marca; no aplicar automáticamente a otras marcas del grupo CEE.
---

# Identidad visual de Camino Selva

Aplicar la identidad del anteproyecto de Diseño Shakespear de septiembre de 2026 y, para web y aplicaciones, la paleta específica indicada por el área de Diseño y aportada por el usuario el 23 de septiembre de 2026. Conservar el carácter territorial, vial y vinculado a la selva misionera. Las instrucciones explícitas del usuario y los materiales aprobados más recientes prevalecen sobre esta referencia.

## Fuente y alcance

Leer [la guía de marca](references/brand-guide.md) antes de diseñar o revisar una pieza. Contiene la paleta, las funciones tipográficas, el catálogo de logos y la procedencia de los recursos.

- **Precedencia para web y aplicaciones:** usar [la paleta web de Diseño](references/web-palette.md). Sustituye los colores derivados del anteproyecto para esos soportes. Verde principal `#19542C`, lima `#B7E768`, bronce `#E5B25D` y naranja `#F6511D`. No reutilizar la paleta anterior como tema digital.
- **Documentado:** formas del logo, tipografías nombradas, mensajes y ejemplos del anteproyecto; colores de la nueva lámina web. Consultar la discrepancia puntual de lima 700 en la referencia web.
- **Derivado:** SVG extraídos del anteproyecto y variantes recoloreadas para web, con procedencia registrada. La indicación sobre color web no aprueba por sí sola todo el anteproyecto.
- **Propuesto:** asignación de colores a componentes, tamaños, espaciado, radios, sombras y sustituciones tipográficas. Resolverlos según el proyecto y distinguirlos de las reglas documentadas.

La ausencia de una especificación no exige detener el trabajo: elegir una solución razonable para el soporte y explicar solo las decisiones que afecten materialmente al resultado. No presentar esas decisiones como normas del diseñador.

## Aplicación

1. Identificar el soporte y los recursos existentes del proyecto. Reutilizar su arquitectura y componentes; incorporar la marca dentro del alcance solicitado.
2. Elegir un SVG según el espacio y el fondo: `assets/logos/web/` para web y aplicaciones; `assets/logos/` conserva las versiones del anteproyecto para otros soportes. Preservar sus proporciones y trazados. El lettering del logo está resuelto en los SVG: no reconstruirlo escribiendo el nombre con una fuente.
3. Para web y aplicaciones, aplicar las escalas verde, lima y bronce y el naranja de la referencia web. Para otros soportes, consultar los colores del anteproyecto y la especificación particular del proyecto. No trasladar automáticamente crema, terracota o rojo tierra a una nueva interfaz.
4. Aplicar Seitu en comunicación institucional, New Transport en información vial e Inter en usos digitales cuando los archivos estén disponibles. La skill no incluye fuentes instalables. Declarar cualquier sustitución efectiva, sin afirmar que una fuente está cargada solo porque figura en CSS.
5. Usar fotografía de rutas, territorio y selva cuando el contenido lo justifique; emplear recortes amplios del símbolo como recurso decorativo. Mantener íntegro el logo que identifica a la marca.
6. Revisar a tamaño real la lectura, el contraste, la proporción del logo y la consistencia entre piezas. En interfaces comprobar también la versión móvil y los estados de interacción.

Para web o aplicaciones, leer [la aplicación digital](references/digital-use.md). Allí se explica el uso de [los tokens JSON](assets/brand-tokens.json), [las variables CSS](assets/brand-tokens.css) y las fuentes de respaldo.

## Decisiones de marca que deben conservarse

- Nombre en texto: **Camino Selva**. Descriptor observado: **Concesionario vial**. Mensaje principal observado: **Conectamos Misiones**.
- No copiar los datos de ejemplo de las maquetas: tarifas, categorías, cuentas de redes y fechas no son información operativa validada.
- No trasladar a Camino Selva la identidad visual de Diseño Shakespear que aparece en los encabezados del PDF. El esquema del grupo CEE es contexto corporativo, no una instrucción para mezclar las marcas.
- No convertir el anteproyecto en una afirmación de cumplimiento de señalización vial, ni deducir autorizaciones o certificaciones a partir de las maquetas.
- Si el usuario pide adaptar este estilo a otra marca, conservar su nombre y recursos propios y describir el resultado como una adaptación solicitada. No insertar los logos de Camino Selva por defecto.

## Entrega

Entregar el trabajo solicitado y resumir las decisiones relevantes: recursos utilizados, sustituciones de fuentes y reglas propuestas cuando las haya. Para una revisión, señalar los problemas concretos y su corrección. No exigir una lista fija de comprobaciones ni generar documentos adicionales si el encargo no los necesita.

Consultar [el PDF fuente](references/camino-selva-anteproyecto-2026-09.pdf) solo cuando sea necesario verificar una composición, una aplicación o una discrepancia con la guía. La skill es autónoma y no depende de la ubicación del PDF original en el equipo.
